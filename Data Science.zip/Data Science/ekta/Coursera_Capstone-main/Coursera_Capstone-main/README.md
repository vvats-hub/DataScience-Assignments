# Applied Data Science Capstone Project
This repository contains the Applied Data Science Capstone Project for IBM Data Science Professional Certification.
